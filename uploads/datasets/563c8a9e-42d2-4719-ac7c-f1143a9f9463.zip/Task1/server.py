import socket

format = 'utf-8'
Data = 16
port = 5050
device_nam = socket.gethostname()
server_ip = socket.gethostbyname(device_nam)

socket_address = (server_ip, port)
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

server.bind(socket_address)
server.listen()
print("Our server is listening...")

while True:
    server_socket, client_add = server.accept()
    print("connected to ", client_add)
    connected = True

    while connected:
        upcoming_msg_len = server_socket.recv(Data).decode(format)
        print("upcoming message lenth is ", upcoming_msg_len.strip())
        msg_len = int(upcoming_msg_len.strip())
        message = server_socket.recv(msg_len).decode(format)

        if message.lower()  == 'disconnect':
            print(('Disconnected with ', client_add))

        print(message)
        server_socket.send("Message recived ".encode(format))

    server_socket.close()

