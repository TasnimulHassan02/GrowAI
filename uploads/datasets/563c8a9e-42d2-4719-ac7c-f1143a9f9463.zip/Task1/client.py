import socket

format = 'utf-8'
Data = 16
port = 5050
device_nam = socket.gethostname()
client_ip = socket.gethostbyname(device_nam)
server_ip = socket.gethostbyname(device_nam)

socket_address = (server_ip, port)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect(socket_address)

def sending_message(msg):
    message = msg.encode(format)
    msg_len = len(message)
    msg_len_str = str(msg_len).encode(format)
    msg_len_str += b' '*(Data - len(msg_len_str))

    client.send(msg_len_str)
    client.send(message)

    sent_from_server = client.recv(128).decode(format)
    print("sent from server", sent_from_server)

sending_message(f"Client's device name is {device_nam} and the ip address is {client_ip}")
sending_message("disconnect")
