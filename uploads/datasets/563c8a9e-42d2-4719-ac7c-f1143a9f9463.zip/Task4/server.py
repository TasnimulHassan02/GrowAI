import socket
import threading

port = 5050
format = 'utf-8'
DATA = 16

device_nam = socket.gethostname()
server_ip = socket.gethostbyname(device_nam)

server_socket_address = (server_ip, port)
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(server_socket_address)

server.listen()
print(f"Server is listening on {server_ip}:{port}")

def client_handle(server_socket, client_add):
    print(f"Connection established with {client_add}")
    connected = True

    while connected:
        upcoming_message_length = server_socket.recv(DATA).decode(format)

        if not upcoming_message_length:
            print(f"Client disconnected at {client_add}.")
            break

        print(f"Upcoming message length: {upcoming_message_length.strip()}")

        message_length = int(upcoming_message_length.strip())
        hour = server_socket.recv(message_length).decode(format)

        if hour.lower() != "disconnect":

            hour = int(hour)
            total_time = 0

            if hour == 0:
                total_time = 0
                server_socket.send(f"No work done, no payment for {hour} hours.".encode(format))

            elif hour > 40:
                total_time = 8000 + ((hour - 40) * 300)
                server_socket.send(f"Total payment for {hour} hours is: {total_time}.".encode(format))

            elif hour < 0:
                total_time = 0
                server_socket.send(f"Invalid input: {hour}. Please enter a non-negative number.".encode(format))

            elif hour <= 40:
                total_time = hour * 200
                server_socket.send(f"Total payment for {hour} hours is: {total_time}.".encode(format))
        else:
            server_socket.send(f"Disconnecting from {client_add}".encode(format))
            print(f"Disconnected with {client_add}")
            connected = False

        print(f"Recieved: {hour}")

    server_socket.close()
while True:
    server_socket, client_add = server.accept()
    thread = threading.Thread(target=client_handle, args=(server_socket, client_add))
    thread.start()