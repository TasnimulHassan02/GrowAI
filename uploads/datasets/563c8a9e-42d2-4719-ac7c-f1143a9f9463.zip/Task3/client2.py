import socket

port = 5050
format = 'utf-8'
data = 16
device_nam = socket.gethostname()
client_ip = socket.gethostbyname(device_nam)
server_ip = socket.gethostbyname(device_nam)

server_socket_address = (server_ip, port)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(server_socket_address)


def sending_message(message):
    msg = message.encode(format)
    msg_length = len(msg)
    msg_length_str = str(msg_length).encode(format)
    msg_length_str += b' ' * (data - len(msg_length_str))

    client.send(msg_length_str)
    client.send(msg)

    sent_from_server = client.recv(128).decode(format)
    print("Server response: ", sent_from_server)


while True:
    message = input("Enter to send: ")
    sending_message(message)
    if message.lower() == "disconnect":
        break