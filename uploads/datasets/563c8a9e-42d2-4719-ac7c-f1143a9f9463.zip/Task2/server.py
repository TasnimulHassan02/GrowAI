import socket

port = 5050
format = 'utf-8'
DATA = 16

device_name = socket.gethostname()
server_ip = socket.gethostbyname(device_name)

server_socket_address = (server_ip, port)
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(server_socket_address)

server.listen()
print(f"Server is listening on {server_ip}:{port}")

while True:
    server_socket, client_add = server.accept()
    print(f"Connection established with {client_add}")
    connected = True

    while connected:
        upcoming_message_length = server_socket.recv(DATA).decode(format)

        if not upcoming_message_length:
            print(f"Client disconnected at {client_add}.")
            break

        print(f"Upcoming message length: {upcoming_message_length.strip()}")

        message_length = int(upcoming_message_length.strip())
        message = server_socket.recv(message_length).decode(format)

        if message.lower() != "disconnect":

            vowels = 'aeiouAEIOU'
            count = 0
            for ch in message:
                if ch in vowels:
                    count += 1
            if count == 0:
                server_socket.send(f"Not enough vowels".encode(format))
            elif count > 2:
                server_socket.send(f"Too many vowels".encode(format))
            else:
                server_socket.send(f"Enough vowels I guess".encode(format))
        else:
            server_socket.send(f"Disconnecting from {client_add}".encode(format))
            print(f"Disconnected with {client_add}")
            connected = False

        print(f"Recieved: {message}")

server_socket.close()